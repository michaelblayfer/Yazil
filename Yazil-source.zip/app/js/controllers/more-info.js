﻿(function (S, C, Y) {
    
    Y.MoreInfoController = function ($scope, $location) {
        $scope.$root.header = "More Info";
    };
    
})(Simple, Cal, Cal.Yazil);