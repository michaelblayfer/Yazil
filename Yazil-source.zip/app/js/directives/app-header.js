﻿(function (S, C, Y) {

    Y.AppHeaderDirective = {
        restrict: 'E',
        templateUrl: 'views/app-header.html',
        scope: true,
        link: function (scope) {
            // bind clicks...
            
        }
    };

})(Simple, Cal, Cal.Yazil);