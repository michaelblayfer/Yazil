﻿(function (S, C, Y) {

    Y.ToolbarDirective = {
        restrict: 'E',
        templateUrl: 'views/toolbar.html',
        link: function (scope) {
            // bind clicks...
        }
    };

})(Simple, Cal, Cal.Yazil);