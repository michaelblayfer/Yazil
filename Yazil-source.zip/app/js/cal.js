﻿Cal = {
    Yazil: {}
};